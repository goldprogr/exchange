<?
include'lib/common.php';
echo $CFG->$_REQUEST['cfg_var'];
?>