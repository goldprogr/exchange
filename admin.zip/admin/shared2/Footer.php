<?php
	class Footer {
		function __construct() {
			echo '</body></html>';
		}
	}
?>